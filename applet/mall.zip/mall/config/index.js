module.exports={
  apiServer:'https://www.lrfc.vip/yimei',//'http://localhost:3002',
  imgServer:'https://www.lrfc.vip/yimei/'//"http://localhost:3002"
}