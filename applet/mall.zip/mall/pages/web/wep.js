Page({
  data:{
    weburl:''
  },
  onLoad(option){
    let weburl = option.weburl
    this.setData({weburl})
  }
})